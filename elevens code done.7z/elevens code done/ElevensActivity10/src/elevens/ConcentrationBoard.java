package elevens;
import java.util.List;
import java.util.ArrayList;

/**
 * The ElevensBoard class represents the board in a game of Concentration.
 */
public class ConcentrationBoard extends Board {

    /**
     * The size (number of cards) on the board.
     */
    private static final int BOARD_SIZE = 16;

    /**
     * The ranks of the cards for this game to be sent to the deck.
     */
    private static final String[] RANKS =
            {"ace", "ace","ace","ace","king", "king", "5", "5", "7", "7", "10", "10", "queen","queen","jack", "jack"};

    /**
     * The suits of the cards for this game to be sent to the deck.
     */
    private static final String[] SUITS =
            {"spades", "clubs", "diamonds", "hearts"};

    /**
     * The values of the cards for this game to be sent to the deck.
     */
    private static final int[] POINT_VALUES =
            {1, 1, 1, 1, 13, 13, 5, 5, 7, 7, 10, 10, 1, 1, 12,12,11,11};



    /**
     * Creates a new <code>ElevensBoard</code> instance.
     */
    public ConcentrationBoard() {
        super(BOARD_SIZE, RANKS, SUITS, POINT_VALUES);
    }

    /**
     * Determines if the selected cards form a valid group for removal.
     * In Elevens, the legal groups are (1) a pair of non-face cards
     * whose values add to 11, and (2) a group of three cards consisting of
     * a jack, a queen, and a king in some order.
     * @param selectedCards the list of the indices of the selected cards.
     * @return true if the selected cards form a valid group for removal;
     *         false otherwise.
     */
    @Override
    public boolean isLegal(List<Integer> selectedCards) {
        if (selectedCards.size() == 2) {
            return containsMatch(selectedCards);
        }
        return false;
    }

    /**
     * Determine if there are any legal plays left on the board.
     * In Elevens, there is a legal play if the board contains
     * (1) a pair of non-face cards whose values add to 11, or (2) a group
     * of three cards consisting of a jack, a queen, and a king in some order.
     * @return true if there is a legal play left on the board;
     *         false otherwise.
     */
    @Override
    public boolean anotherPlayIsPossible() {
        List<Integer> cIndexes = cardIndexes();
        return containsMatch(cIndexes);
    }

    /**
     * Check for a match in the selected cards.
     * @param selectedCards selects a subset of this board.  It is list
     *                      of indexes into this board that are searched
     *                      to find a match.
     * @return true if the board entries in selectedCards
     *              contain a match(same color and same rank); false otherwise.
     */
    private boolean containsMatch(List<Integer> selectedCards) {
        for(int i = 0; i < selectedCards.size(); i++)
        {
            for(int j = 0; j < selectedCards.size(); j++){
                if(i!=j && cardAt(selectedCards.get(i)).pointValue()==cardAt(selectedCards.get(j)).pointValue()){
                    if(i!=j && cardAt(selectedCards.get(i)).color().equals(cardAt(selectedCards.get(j)).color())){
                    return true;}
                }
            }
        }


        return false;
    }
}
